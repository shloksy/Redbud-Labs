/*
 * reset.h
 *
 *  Created on: May 5, 2021
 *      Author: dsmoot
 */

#ifndef APP_COMMON_INCLUDE_RESET_H_
#define APP_COMMON_INCLUDE_RESET_H_


void software_reset(void);


#endif /* APP_COMMON_INCLUDE_RESET_H_ */
