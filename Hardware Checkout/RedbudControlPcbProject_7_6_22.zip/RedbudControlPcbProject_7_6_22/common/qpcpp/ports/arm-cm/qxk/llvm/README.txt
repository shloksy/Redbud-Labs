The port to ARM-LLVM toolchain is identical to ARM-CLANG
and is located in ports/arm-cm/armclang/ sub-directory