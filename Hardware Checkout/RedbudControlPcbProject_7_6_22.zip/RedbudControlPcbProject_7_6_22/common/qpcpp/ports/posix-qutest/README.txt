This QP port is for the QUTest unit testing harness.

If you are interested in using a POSIX target as embedded platform,
consider the following QP ports:

- posix     for multithreaded (P-threads) QP applications
- posix-qv  single-threaded QP port to POSIX


NOTE:
Building of the QP libraries on the POSIX targets or hosts
is no longer necessary. The example projects for POSIX are
built directly from QP source files and don't need a library.

Quantum Leaps
04/05/2018