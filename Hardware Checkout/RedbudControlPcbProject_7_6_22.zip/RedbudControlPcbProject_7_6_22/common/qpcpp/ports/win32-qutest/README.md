# Win32-API (Windows port for QUTest Unit Testing Harness)

Documentation for this port is available in the QP/C Manual at:

- https://www.state-machine.com/qpcpp/win32-qutest.html
