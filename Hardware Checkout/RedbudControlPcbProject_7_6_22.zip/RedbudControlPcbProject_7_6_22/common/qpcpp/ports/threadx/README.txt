This directory contains a generic platform-independent QP/C port
to ThreadX.

Typically, you don't need to change any of the files in this directory
to run QP-ThreadX port on any CPU/Compiler to which ThreadX has been
ported, because all the CPU and compiler specifics are handled by the
ThreadX RTOS.

Quantun Leaps
state-machine.com
info@state-machine.com