# POSIX (single-threaded)

Documentation for this port is available in the QP/C Manual at:

- https://www.state-machine.com/qpcpp/posix-qv.html
