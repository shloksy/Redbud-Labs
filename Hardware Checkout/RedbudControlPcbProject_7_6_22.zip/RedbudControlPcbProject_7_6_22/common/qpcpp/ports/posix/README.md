# POSIX (multi-threaded with p-threads)

Documentation for this port is available in the QP/C Manual at:

- https://www.state-machine.com/qpcpp/posix.html
