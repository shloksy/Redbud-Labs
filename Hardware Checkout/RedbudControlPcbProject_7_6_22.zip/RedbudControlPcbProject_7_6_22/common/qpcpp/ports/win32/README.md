# Win32-API (Windows multi-threaded with Win32-threads)

Documentation for this port is available in the QP/C Manual at:

- https://www.state-machine.com/qpcpp/win32.html
