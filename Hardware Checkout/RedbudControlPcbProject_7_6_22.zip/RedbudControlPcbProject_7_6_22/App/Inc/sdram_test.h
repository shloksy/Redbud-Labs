/**
 * @file sdram_test.h
 *
 * @author awong
 */

#ifndef INC_SDRAM_TEST_H_
#define INC_SDRAM_TEST_H_

namespace sdram_test {

void benchmark_sdram();

}

#endif /* INC_SDRAM_TEST_H_ */
