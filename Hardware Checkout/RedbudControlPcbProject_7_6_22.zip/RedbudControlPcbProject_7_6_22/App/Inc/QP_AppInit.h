/*
 * QP_AppInit.h
 * Logic for initializing the QP application.
 *
 *  Created on: Dec 15, 2021
 *      Author: jcochran
 */

#ifndef APP_INC_QP_APPINIT_H_
#define APP_INC_QP_APPINIT_H_

void QP_AppInit(int argv = 0, const char* argc[] = nullptr);

#endif /* APP_INC_QP_APPINIT_H_ */
